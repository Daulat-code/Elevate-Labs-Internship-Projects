package com.cb.daulat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobPortalSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
